package com.muneiah.example.myroomdb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class UpdateActivity extends AppCompatActivity {
EditText editText1,editText2;
StudentEntity entity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        editText1=findViewById(R.id.et_name_update);
        editText2=findViewById(R.id.et_id_update);
        Intent i=getIntent();
        String n=i.getStringExtra("name");
        String ee=i.getStringExtra("roll");
        editText1.setText(n);
        editText2.setText(ee);
    }

    public void supdateData(View view) {
        String a=editText1.getText().toString();
        String b=editText2.getText().toString();
        entity=new StudentEntity();
        entity.setName(a);
        entity.setRollnumber(b);
        MainActivity.dataBase.studentDAO().update(entity);

    }
}