package com.example.mysharedprefarences;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
EditText et1,et2,et3;
static SharedPreferences sp;
SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        et1=findViewById(R.id.editText_name);
        et2=findViewById(R.id.editTextpass);
        et3=findViewById(R.id.editText_cnf);
        sp=getSharedPreferences("auth",MODE_PRIVATE);
    }

    public void registerData(View view) {
        editor=sp.edit();
        String n1=et1.getText().toString();
        String n2=et2.getText().toString();
        String n3=et3.getText().toString();
        if (n2.equals(n3)){
            editor.putString("key1",n1);
            editor.putString("key2",n2);
            editor.putString("key3",n3);
            editor.apply();
            Toast.makeText(this, "registered success", Toast.LENGTH_SHORT).show();
            Intent intent=new Intent(this,MainActivity.class);
            startActivity(intent);
        }else {
            Toast.makeText(this, "mismatch the password", Toast.LENGTH_SHORT).show();
        }
    }

}
