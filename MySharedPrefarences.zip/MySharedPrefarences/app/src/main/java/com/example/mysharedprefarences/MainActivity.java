package com.example.mysharedprefarences;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
EditText n,p;
SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        n=findViewById(R.id.editText);
        p=findViewById(R.id.editText2);
        sp=getSharedPreferences("auth",MODE_PRIVATE);

    }

    public void loginpage(View view) {
        String a=n.getText().toString().toString();
        String aa=p.getText().toString().toString();

       String nn=RegisterActivity.sp.getString("key1","");
       String pp= RegisterActivity.sp.getString("key2","");
       SharedPreferences.Editor editor=sp.edit();

       if (nn.equals(a) && pp.equals(aa)){
           Toast.makeText(this, "Login Success", Toast.LENGTH_SHORT).show();
       }
       else {
           Toast.makeText(this, "Faild", Toast.LENGTH_SHORT).show();
       }


    }

    public void registerpage(View view) {
        Intent intent=new Intent(this,RegisterActivity.class);
        startActivity(intent);
    }
}
